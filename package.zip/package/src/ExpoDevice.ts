import { requireNativeModule } from 'expo-modules-core';
export default requireNativeModule('ExpoDevice');
